public class Node {
    Course course;
    Node next;

    public Node(Course course) {
        this.course = course;
        this.next = null;
    }
}